// lib/features/common/models/dus_khari_row.dart

import 'package:akkha_rik_lipi_sipal/features/common/models/akkha_unit.dart';

/// A single 10-Khari row: one base consonant + its list of vowel-forms.
class DusKhariRow {
  final AkkhaUnit baseUnit;
  final List<AkkhaUnit> syllableUnits;

  DusKhariRow({required this.baseUnit, required this.syllableUnits});

  /// Build from JSON + a lookup map of character → AkkhaUnit.
  /// Falls back to `AkkhaUnit.fromJson(...)` so we always satisfy its
  /// required `id` and `type` parameters.
  factory DusKhariRow.fromJson(
    Map<String, dynamic> json,
    Map<String, AkkhaUnit> lookup,
  ) {
    // Look up the base character
    final baseChar = json['baseChar'] as String;
    final baseUnit =
        lookup[baseChar] ??
        // Fallback: use fromJson so we don't forget id/type
        AkkhaUnit.fromJson({
          'id': baseChar,
          'type': 'unknown',
          'character': baseChar,
          'transliteration': '',
          'hindiTransliteration': '',
        });

    // Build the list of syllable units
    final rawSylls = List<String>.from(json['syllables'] as List<dynamic>);
    final syllUnits = rawSylls.map((ch) {
      return lookup[ch] ??
          AkkhaUnit.fromJson({
            'id': ch,
            'type': 'unknown',
            'character': ch,
            'transliteration': '',
            'hindiTransliteration': '',
          });
    }).toList();

    return DusKhariRow(baseUnit: baseUnit, syllableUnits: syllUnits);
  }
}
