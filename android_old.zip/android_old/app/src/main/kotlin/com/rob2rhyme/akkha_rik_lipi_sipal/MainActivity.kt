package com.rob2rhyme.akkha_rik_lipi_sipal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
